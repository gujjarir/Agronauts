package edu.neu.db.dbdemo;

import java.util.List;

public interface FarmerDao {
	List<FarmerDetails> getAllFarmerDetails();
}
