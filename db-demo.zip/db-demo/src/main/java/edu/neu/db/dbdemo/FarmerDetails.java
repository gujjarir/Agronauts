package edu.neu.db.dbdemo;

public class FarmerDetails {
	private String farmerID, address, paymentStatus, requestDate;
	private double area;

	public FarmerDetails(String farmerID, double area, String address, String paymentStatus, String requestDate) {
		this.farmerID = farmerID;
		this.area = area;
		this.address = address;
		this.paymentStatus = paymentStatus;
		this.requestDate = requestDate;
	}

	public String getFarmerID() {
		return farmerID;
	}

	public void setFarmerID(String farmerID) {
		this.farmerID = farmerID;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}
	public String toString(){
		return farmerID + address + paymentStatus + area + requestDate ;
		
	}

}
