package edu.neu.db.dbdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FarmerDaoImpl implements FarmerDao {

	private static final String JDBC_URL = "jdbc:mysql://10.0.0.93:3306/WEBTOOLS?user=root&password=bitnami";;

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<FarmerDetails> getAllFarmerDetails() {
		List<FarmerDetails> fdList = new ArrayList<FarmerDetails>();
		try {

			Connection connection = DriverManager.getConnection(JDBC_URL);

			PreparedStatement ps = connection.prepareStatement("SELECT * FROM AGRO.DemoTable");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String fId = rs.getString("Farmer_Id");
				Double area = rs.getDouble("Area");
				String address = rs.getString("Address");
				String pStatus = rs.getString("Payment_status");
				String reqDate = rs.getString("Request_Date");

				FarmerDetails fd = new FarmerDetails(fId, area, address, pStatus, reqDate);
				fdList.add(fd);

			}
			;

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return fdList;
	}

}
