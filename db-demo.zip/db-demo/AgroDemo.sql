

Drop Table if exists DemoTable;

CREATE TABLE DemoTable(
	Farmer_Id varchar(100),
	Area decimal(10,3),
	Address varchar(100),
	Payment_status varchar(20),
	Request_Date varchar(20)
);

insert into DemoTable values
(1,220.3,"15,TREMONT ST","Y","2016.19.11"),
("2y",300,"300 Huntington Ave","N", "2005.20.19"),
("4T",1000,"30 State Street","N", "1990.2.1"),
("12A",489,"98 Richmond Ave","Y", "2010.09.09"),
("18T",1700,"30 Salem St","Y", "2009.10.19"),
("45",2000,"4949 Main St","Y", "2015.8.10")
;
